enum TAG { login, game }
enum LANGUAGE { go, dart, js, python, java, kotlin, swift }
