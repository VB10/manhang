import 'package:flutter/material.dart';
import 'package:manhang/model/BaseEnum.dart';


class QuestionVC {
  Map<LANGUAGE, String> languageWords = new Map<LANGUAGE, String>();
  Question() {
    setLanguageWord();
  }

  String convertList(String word, List<String> _listWord, String inputValue) {
    //Control all word character and search have questionword character
    //equals userword
    for (var i = 0; i < _listWord.length; i++) {
      if (word[i] == inputValue) {
        _listWord[i] = inputValue;
      }
    }
    //Create new list and have refresh data
    var _newList = _listWord.map((data) => "$data ");
    //Last underline question word update.
    return _newList.join("");
  }

//The user will see final alert dialog.
  void endGame(bool result, BuildContext context) {
    // if (!questionWord.contains("_")) {
      
    // }
    showDialog(
        context: context,
        builder: (BuildContext context) => new AlertDialog(
              content: Image.asset(
                "assets/gif/${result ? "tenor" : "fail"}.gif",
              ),
              backgroundColor: Colors.transparent,
            )).whenComplete(() => {Navigator.pop(context, true)});
    return;
  }

//set language arrays item.
  setLanguageWord() {
    languageWords[LANGUAGE.dart] =
        "helps you craft beautiful, high-quality experiences across all screens";
    languageWords[LANGUAGE.go] =
        "that makes it easy to build simple, reliable, and efficient software.";
    languageWords[LANGUAGE.java] = "is at the heart of our digital lifestyle.";
    languageWords[LANGUAGE.swift] =
        "Our goals for Swift are ambitious: we want to make programming simple things easy, and difficult things possible";
    languageWords[LANGUAGE.kotlin] = "Dont't block keep moving";
    languageWords[LANGUAGE.python] =
        " is a programming language that lets you work quickly and integrate systems more effectively";
  }
}
